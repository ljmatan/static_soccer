import 'dart:async';
import 'dart:collection';

import 'package:flutter/material.dart';
import 'package:static_soccer/views/match/bloc/timer_controller.dart';
import 'package:static_soccer/views/match/info_bar/timer/animated_time.dart';
import 'package:static_soccer/views/match/info_bar/timer/kick_opportunity_dialog.dart';
import 'package:static_soccer/views/match/info_bar/timer/time_controller.dart';

class MatchTimer extends StatefulWidget {
  final Function setInput;

  MatchTimer(Key key, {@required this.setInput}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return MatchTimerState();
  }
}

class MatchTimerState extends State<MatchTimer> {
  Set<int> _redTeamShots = {};
  Set<int> _blueTeamShots = {};

  void setShotsNumber(Set red, Set blue) {
    _redTeamShots = SplayTreeSet.from(red);
    _blueTeamShots = SplayTreeSet.from(blue);
  }

  int minutesLeft = 0;

  Timer _timer;
  void _setTimer() => _timer = Timer.periodic(
        const Duration(milliseconds: 333),
        (timer) async {
          minutesLeft += 1;
          if (minutesLeft >= 90) {
            timer.cancel();
            minutesLeft = 90;
          }
          TimeController.change(minutesLeft);
          if (timer.isActive) {
            for (var minute in _blueTeamShots)
              if (minute == minutesLeft) {
                timer.cancel();
                final bool shoot = await showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => KickDialog(
                    label: 'Goal Scoring Opportunity',
                  ),
                );
                if (shoot) widget.setInput(true);
              }
            for (var minute in _redTeamShots)
              if (minute == minutesLeft) {
                timer.cancel();
                final bool shoot = await showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => KickDialog(
                    label: 'Red Team Shoot',
                  ),
                );
                if (shoot) widget.setInput(false);
              }
          }
        },
      );

  StreamSubscription _timerSubscription;

  @override
  void initState() {
    super.initState();
    _setTimer();
    TimerController.init();
    _timerSubscription = TimerController.stream.listen(
      (shotStart) => _setTimer(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        boxShadow: kElevationToShadow[2],
        color: Colors.white,
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 14, 24, 14),
        child: StreamBuilder(
          stream: TimeController.stream,
          initialData: minutesLeft,
          builder: (context, minutes) => AnimatedTime(minutes: minutes.data),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _timerSubscription.cancel();
    TimerController.dispose();
    _timer?.cancel();
    super.dispose();
  }
}
