import 'dart:math';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:static_soccer/views/match/bloc/gameplay_controller.dart';
import 'package:static_soccer/views/match/bloc/score_controller.dart';
import 'package:static_soccer/views/match/bloc/timer_controller.dart';
import 'package:static_soccer/views/match/shot_display/button_row.dart';
import 'package:static_soccer/views/match/shot_display/player_name_display.dart';
import 'package:static_soccer/views/match/shot_display/timer.dart';
import 'package:video_player/video_player.dart';

class VideoDisplay extends StatefulWidget {
  final bool requiresInput;
  final String mode, color, thumbnail;

  VideoDisplay({
    @required this.requiresInput,
    @required this.mode,
    @required this.color,
    @required this.thumbnail,
  });

  @override
  State<StatefulWidget> createState() {
    return _VideoDisplayState();
  }
}

class _VideoDisplayState extends State<VideoDisplay>
    with SingleTickerProviderStateMixin {
  AnimationController _animationController;
  Animation<double> _scale;
  VideoPlayerController _playerController, _shotController;

  VideoPlayerController _videoController;

  // You could replace filenames with 0, 1, 2 etc. and remove this parameter from PlayModeButton class
  final List<String> _cornerPlayers = [
    'Cris',
    'Fabio',
    'Franz',
    'Leon',
    'TheWall',
  ];
  final List<String> _crossPlayers = [
    'Cris',
    'Fabio',
    'Leon',
    'Luis',
    'Samurai',
  ];
  final List<String> _freeKickPlayers = [
    'Cris',
    'Crossham',
    'Diego',
    'Dinho',
    'Leon',
  ];
  final List<String> _passPlayers = [
    'Cris',
    'Crossham',
    'Diego',
    'Dinho',
    'Leon',
  ];
  final List<String> _penaltyPlayers = [
    'Cris',
    'Crossham',
    'Franz',
    'Leon',
    'Luis'
  ];
  final List<String> _shootPlayers = [
    'Cris',
    'Diego',
    'Dinho',
    'Leon',
    'TheWall',
  ];

  final List<String> _shots = [
    'Goal1',
    'Goal2',
    'Hold',
    'Miss',
  ];

  // Add 3 random player vids
  Set<String> _players = {};

  void _setPlayers() {
    while (_players.length < 3)
      switch (widget.mode) {
        case 'Corner':
          _players.add(_cornerPlayers[Random().nextInt(4)]);
          break;
        case 'Cross':
          _players.add(_crossPlayers[Random().nextInt(4)]);
          break;
        case 'Freekick':
          _players.add(_freeKickPlayers[Random().nextInt(4)]);
          break;
        case 'Pass':
          _players.add(_passPlayers[Random().nextInt(4)]);
          break;
        case 'Penalty':
          _players.add(_penaltyPlayers[Random().nextInt(4)]);
          break;
        case 'Shoot':
          _players.add(_shootPlayers[Random().nextInt(4)]);
          break;
      }
  }

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..addListener(() => setState(() {}));
    _scale = Tween<double>(begin: 0.1, end: 1).animate(_animationController);

    _animationController.forward();

    _setPlayers();
  }

  Future<void> _setVideos() async {
    // Set new controller according to the user choice
    setState(() => _videoController = _playerController);
    // Play the video (note: await doesn't wait for the video to finish)
    await _videoController.play();
    // Wait until the video had stopped playing
    await Future.delayed(_videoController.value.duration, () async {
      // Continue with the random shot video
      setState(() => _videoController = _shotController);
      if (_videoController.dataSource.endsWith('Goal1.mp4') ||
          _videoController.dataSource.endsWith('Goal2.mp4'))
        ScoreController.hit(
          _videoController.dataSource.contains('Red') ? 'red' : 'blue',
        );
      await _videoController.play();
      await Future.delayed(
        _videoController.value.duration,
        () async {
          // Reverse the animation, then destroy widget
          await _animationController.reverse();
          GameplayController.change(false);
          TimerController.change(0);
        },
      );
    });
  }

  Future<void> _setControllers(int i) async {
    String playerVideo, shotVideo;

    // Block touch events
    showDialog(
        context: context,
        barrierColor: Colors.transparent,
        barrierDismissible: false,
        builder: (context) => const SizedBox());

    // Assign video values
    playerVideo =
        'assets/${widget.mode}/1_SelectPlayer/${widget.color}_${_players.elementAt(i)}.mp4';

    final int random = Random().nextInt(10);
    final int shotIndex = random <= 3
        ? 0
        : random > 3 && random <= 6
            ? 1
            : random > 6 && random <= 8
                ? 2
                : 3;
    shotVideo =
        'assets/${widget.mode}/2_Result/${widget.color}_${_shots[shotIndex]}.mp4';

    // Initialize videos and their respective controllers
    try {
      _playerController = VideoPlayerController.asset(playerVideo);
      _shotController = VideoPlayerController.asset(shotVideo);

      await _playerController.initialize();
      await _shotController.initialize();
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    }

    // Enable touch events
    Navigator.pop(context);

    _setVideos();
  }

  final StreamController _timerController = StreamController.broadcast();
  void _hideTimer() => _timerController.add(false);

  final StreamController _playerNameController = StreamController.broadcast();
  void _showPlayerName(String name) => _playerNameController.add(name);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Opacity(
          opacity: _animationController.value,
          child: Transform.scale(
            scale: _scale.value,
            child: _videoController == null
                ? Image.asset(
                    widget.thumbnail,
                    fit: BoxFit.cover,
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                  )
                : SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _videoController.value.size?.width ?? 0,
                        height: _videoController.value.size?.height ?? 0,
                        child: VideoPlayer(_videoController),
                      ),
                    ),
                  ),
          ),
        ),
        Center(
          child: StreamBuilder(
            stream: _timerController.stream,
            initialData: true,
            builder: (context, visible) => AnimatedOpacity(
              opacity: visible.data ? 1 : 0,
              duration: const Duration(milliseconds: 300),
              child: DecisionTimer(
                hide: _hideTimer,
                setControllers: _setControllers,
                visible: visible.data,
                short: !widget.requiresInput,
                playerNames: _players.toList(),
                showPlayerName: _showPlayerName,
              ),
            ),
          ),
        ),
        Center(
          child: StreamBuilder(
            stream: _playerNameController.stream,
            builder: (context, name) => name.hasData
                ? PlayerNameDisplay(
                    name: name.data.startsWith('KEEP')
                        ? name.data.substring(4)
                        : name.data)
                : const SizedBox(),
          ),
        ),
        if (widget.requiresInput)
          Positioned(
            bottom: MediaQuery.of(context).size.height / 10,
            left: 16,
            right: 16,
            child: ButtonRow(
              setControllers: _setControllers,
              names: _players.toList(),
              hideTimer: _hideTimer,
              showPlayerName: _showPlayerName,
              nameStream: _playerNameController.stream,
            ),
          ),
      ],
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _timerController.close();
    _playerNameController.close();
    _playerController.dispose();
    _shotController.dispose();
    super.dispose();
  }
}
