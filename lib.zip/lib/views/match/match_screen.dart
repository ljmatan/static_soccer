import 'dart:math';

import 'package:flutter/material.dart';
import 'package:static_soccer/logic/matchmaking/matchmaking.dart';
import 'package:static_soccer/views/match/bloc/gameplay_controller.dart';
import 'package:static_soccer/views/match/bloc/score_controller.dart';
import 'package:static_soccer/views/match/continue_button.dart';
import 'package:static_soccer/views/match/info_bar/info_bar.dart';
import 'package:static_soccer/views/match/info_bar/timer/time_controller.dart';
import 'package:static_soccer/views/match/info_bar/timer/timer.dart';
import 'package:static_soccer/views/match/shot_display/shot_display.dart';

class MatchScreen extends StatefulWidget {
  final Shots shots;

  MatchScreen({@required this.shots});

  @override
  State<StatefulWidget> createState() {
    return _MatchScreenState();
  }
}

class _MatchScreenState extends State<MatchScreen> {
  final GlobalKey<MatchTimerState> _timerKey = GlobalKey();

  Set<int> _redTeamShots = {};
  Set<int> _blueTeamShots = {};

  @override
  void initState() {
    super.initState();
    GameplayController.init();
    TimeController.init();
    ScoreController.init();
    while (_redTeamShots.length < widget.shots.redTeamShots) {
      final int minute = 2 + Random().nextInt(86);
      bool acceptable = true;
      for (var shot in _redTeamShots)
        if (minute - 1 == shot || minute + 1 == shot) acceptable = false;
      for (var shot in _blueTeamShots) if (minute == shot) acceptable = false;
      if (acceptable) _redTeamShots.add(minute);
    }
    while (_blueTeamShots.length < widget.shots.blueTeamShots) {
      final int minute = 2 + Random().nextInt(86);
      bool acceptable = true;
      for (var shot in _blueTeamShots)
        if (minute - 1 == shot || minute + 1 == shot) acceptable = false;
      for (var shot in _redTeamShots) if (minute == shot) acceptable = false;
      if (acceptable) _blueTeamShots.add(minute);
    }
    WidgetsBinding.instance.addPostFrameCallback((_) =>
        _timerKey.currentState.setShotsNumber(_redTeamShots, _blueTeamShots));
  }

  final List<String> _modes = [
    'Corner',
    'Cross',
    'Freekick',
    'Pass',
    'Penalty',
    'Shoot',
  ];

  bool _requiresInput;
  String _mode, _color, _thumbnail;

  void _setInput(bool value) {
    _requiresInput = value;
    _color = value ? 'Blue' : 'Red';
    _mode = _modes[Random().nextInt(6)];
    _thumbnail = 'assets/$_mode/${_color}_thumbnail.png';
    GameplayController.change(true);
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      child: Scaffold(
        body: Stack(
          children: [
            Column(
              children: [
                InfoBar(_timerKey, setInput: _setInput),
              ],
            ),
            ContinueButton(),
            StreamBuilder(
              stream: GameplayController.stream,
              initialData: false,
              builder: (context, displayed) => displayed.data
                  ? VideoDisplay(
                      requiresInput: _requiresInput,
                      mode: _mode,
                      color: _color,
                      thumbnail: _thumbnail,
                    )
                  : const SizedBox(),
            ),
          ],
        ),
      ),
      onWillPop: () async => _timerKey.currentState.minutesLeft == 0,
    );
  }

  @override
  void dispose() {
    GameplayController.dispose();
    TimeController.dispose();
    ScoreController.dispose();
    super.dispose();
  }
}
