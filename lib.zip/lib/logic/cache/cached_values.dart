enum Cached {
  redStrength,
  blueStrength,
}

extension CachedExtension on Cached {}
